# CustomSceneryModTemplate
Mod template for custom scenery

See https://parkitectnexus.com/modding-wiki for documentation
